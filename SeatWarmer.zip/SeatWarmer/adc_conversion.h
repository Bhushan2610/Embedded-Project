#ifndef ADC_CONVERSION_H_INCLUDED
#define ADC_CONVERSION_H_INCLUDED

uint16_t adc(uint8_t ch);
void InitADC();

#endif // ADC_CONVERSION_H_INCLUDED
