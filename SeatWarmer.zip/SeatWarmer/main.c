#include <avr/io.h>
#include<util/delay.h>
#include "adc_conversion.h"
#include "set_port.h"
#include "set_pwm.h"
#include "uart.h"


void peripheral_init(void)
{
    InitLED();
    InitADC();
    InitPWM();
    InitUART(103);
}

uint16_t temp;
char temp_data;

int main(void)
{

    peripheral_init();
    while(1)
    {
        if(SWITCH_1_ON)
        {

            if(SWITCH_2_ON)
            {
                led(LED_ON);
                temp=adc(0);
                pwm(temp);
                UARTwrite(temp_data);
            }

            else

            {

                led(LED_OFF);
            }

        }

        else
        {
            led(LED_OFF);
            OCR1A=0;
        }

    }

    return 0;
}
