#include"set_pwm.h"
#include<util/delay.h>
#include<avr/io.h>



void InitPWM(void)
{
    TCCR1A|=(1<<COM1A1)|(1<<WGM10)|(1<<WGM11);
    TCCR1B|=(1<<WGM12)|(1<<CS11)|(1<<CS10);
    DDRB|=(1<<PB1);

}


void pwm (uint16_t ticks)
{


    if((ticks>=0) && (ticks<=103))
        {

        OCR1A = 103;

        _delay_ms(20);
    }
    else if((ticks>=104) && (ticks<=205))
        {

        OCR1A = 205;

       _delay_ms(20);
    }
    else if((ticks>=206) && (ticks<=308))
        {

        OCR1A = 308;

        _delay_ms(20);
    }
    else if((ticks>=309) && (ticks<=410))
        {

        OCR1A = 410;

        _delay_ms(20);
    }
    else if((ticks>=411) && (ticks<=512))
        {

        OCR1A = 512;

        _delay_ms(20);
    }
    else if((ticks>=513) && (ticks<=615))
        {

        OCR1A = 615;

        _delay_ms(20);
    }
    else if((ticks>=616) && (ticks<=717))
        {

        OCR1A = 717;

        _delay_ms(20);
    }
    else if((ticks>=718) && (ticks<=820))
        {

        OCR1A = 820; //80% duty cycle

        _delay_ms(20);
    }
    else if((ticks>=821) && (ticks<=922))
        {

        OCR1A = 922;

        _delay_ms(20);
    }
    else if((ticks>=923) && (ticks<=1024))
        {

        OCR1A = 1024;

        _delay_ms(20);
    }
    else
    {
        OCR1A = 0;

    }
}
