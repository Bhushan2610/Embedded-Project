#ifndef SET_PWM_H_INCLUDED
#define SET_PWM_H_INCLUDED

#include<avr/io.h>



void pwm(uint16_t temp_value);
void InitPWM(void);


#endif // SET_PWM_H_INCLUDED
